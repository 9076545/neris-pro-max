// ===== Login e cadastro pelo servidor da Neris (cole no nexus-central, antes do roteamento de /api/chat) =====
// O navegador fala só com o domínio da Neris. O servidor fala com o provedor de autenticação,
// usando SUPABASE_URL e SUPABASE_ANON_KEY que já existem como bindings do Worker.

function mensagemSegura(data, kind) {
  const m = String(data.msg || data.error_description || data.message || "");
  if (/invalid login|invalid_credentials/i.test(m)) return "E-mail ou senha incorretos.";
  if (/already registered|already exists|user already/i.test(m)) return "Já existe uma conta com esse e-mail.";
  if (/email not confirmed/i.test(m)) return "Confirme seu e-mail para entrar.";
  if (/password/i.test(m) && /least|short|characters/i.test(m)) return "A senha precisa ter pelo menos 6 caracteres.";
  return kind === "login"
    ? "Não foi possível entrar agora. Tente de novo."
    : "Não foi possível criar a conta agora. Tente de novo.";
}

async function handleAuth(request, env, headers, kind) {
  const body = await readJson(request);
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");
  if (!email || !password) return json({ msg: "Informe e-mail e senha." }, 400, headers);
  if (email.length > 254 || password.length > 200) return json({ msg: "Dados inválidos." }, 400, headers);

  const base = String(env.SUPABASE_URL || "").replace(/\/$/, "");
  const caminho = kind === "login" ? "/auth/v1/token?grant_type=password" : "/auth/v1/signup";
  let res;
  try {
    res = await fetch(base + caminho, {
      method: "POST",
      headers: { apikey: env.SUPABASE_ANON_KEY, "content-type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
  } catch (err) {
    return json({ msg: "Serviço de conta indisponível. Tente em instantes." }, 503, headers);
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    return json({ msg: mensagemSegura(data, kind) }, res.status >= 500 ? 503 : 400, headers);
  }
  return json({
    access_token: data.access_token || null,
    user: data.user || null,
    msg: data.access_token ? null : "Conta criada. Confirme seu e-mail para entrar.",
  }, 200, headers);
}

// Rotas (inserir no roteamento, antes de /api/chat):
//   if (path === "/api/auth/login" && request.method === "POST")  return handleAuth(request, env, headers, "login");
//   if (path === "/api/auth/signup" && request.method === "POST") return handleAuth(request, env, headers, "signup");
