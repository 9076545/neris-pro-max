---
name: auditoria-assinaturas
description: Revisa a lista de assinaturas e ferramentas pagas e sugere alternativas gratuitas ou open source. Use quando o usuário quer reduzir custos com software.
---

# Auditoria de assinaturas

## Objetivo
Listar cada assinatura, calcular o custo mensal e anual, e sugerir substituições open source ou gratuitas, com o que se perde em cada troca.

## Entrada
Nome da ferramenta, valor mensal, uso real (o que o usuário faz nela) e quantas pessoas usam.

## Passo a passo
1. Monte a tabela com nome, valor mensal, valor anual e uso.
2. Calcule o total mensal e anual.
3. Para cada item, indique uma alternativa com o que ela cobre e o que não cobre. Exemplos citados nos vídeos de referência: Higgsfield para vídeo com IA, ElevenLabs para voz, Wispr Flow para ditado, Intercom para atendimento, Loom para gravação de tela.
4. Classifique: trocar já, testar antes, manter. Mantenha o que tem suporte ou dados que não podem ser migrados sem risco.
5. Peça confirmação antes de cancelar qualquer assinatura.

## Regras
- Confirme que a alternativa ainda existe e tem licença adequada para uso comercial antes de recomendar.
- Não recomende cancelar sem conhecer o uso.
- Valores de assinatura mudam; avise que os preços são os informados pelo usuário.

## Formato
Tabela (ferramenta, mensal, anual, uso), total, depois a lista de trocas com "perde / ganha".
