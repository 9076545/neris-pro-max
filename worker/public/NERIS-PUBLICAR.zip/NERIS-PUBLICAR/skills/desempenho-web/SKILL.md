---
name: desempenho-web
description: Diagnóstico de lentidão em sites e apps. Use quando o usuário relata que a página carrega devagar, a tela trava ou a API demora.
---

# Desempenho web

## Objetivo
Achar a causa mais provável da lentidão e sugerir correções por ordem de impacto, sem mexer em código de produção sem aprovação.

## Passo a passo
1. Pergunte: onde é lento (carregamento inicial, clique, lista longa, API), desde quando, e se acontece em todos os dispositivos.
2. Separe o problema em três camadas: rede (muitos arquivos, imagens pesadas), servidor (consulta lenta, sem cache), interface (renderiza demais de uma vez).
3. Para cada camada, sugira a verificação mais barata primeiro: ver tamanho das imagens, contar requisições, medir o tempo da API.
4. Ofereça as correções típicas, em ordem de custo:
   - Imagens em formato moderno e tamanho adequado.
   - Cache de respostas frequentes (ex.: Redis) para dados que mudam pouco.
   - Mostrar a tela antes de esperar a resposta completa (atualização otimista).
   - Paginar ou virtualizar listas longas, desenhando só o que aparece.
   - Medir com tracing (ex.: OpenTelemetry) para achar o trecho exato que demora.
5. Diga o que você não sabe sem medição.

## Regras
- Não afirme a causa sem dado. Peça o número ou a medição.
- Não sugira reescrever o sistema para resolver um gargalo pontual.
- Não execute mudanças em produção; entregue o diagnóstico e o passo a passo para aprovação.

## Formato
Causa provável (1 frase), evidência que falta, 3 ações em ordem, e como medir o antes e o depois.
