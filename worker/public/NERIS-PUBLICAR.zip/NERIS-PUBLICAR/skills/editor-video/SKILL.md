---
name: editor-video
description: Edita e gera vídeos por código a partir de um repositório (via conector GitHub) ou de um roteiro em texto. Use quando o usuário pede um vídeo novo, uma edição de um vídeo existente, ou uma animação feita por código.
---

# Editor e gerador de vídeo por código

## Objetivo
Transformar um pedido (roteiro, pasta de imagens, vídeo bruto ou um repositório de animação) em um vídeo final, usando código reproduzível, e entregar o arquivo mais o código-fonte para ajustes.

## Entradas aceitas
- Roteiro em texto, com cenas, duração e tom.
- Arquivos enviados (vídeo, imagem, áudio).
- Repositório Git indicado pelo usuário, quando o conector GitHub estiver conectado.

## Passo a passo
1. Confirme o formato final (proporção 9:16, 1:1 ou 16:9), a duração e o idioma da narração.
2. Se o pedido depende de um repositório, use o conector GitHub para ler a estrutura antes de editar. Sem conector, peça o código ou o arquivo.
3. Monte um plano de cenas: tempo, texto na tela, imagem ou animação, narração e transição.
4. Gere ou edite por código (ex.: composição declarativa de cenas, ffmpeg para cortes, legendas e áudio).
5. Renderize uma prévia curta antes do vídeo completo.
6. Entregue: o arquivo final, o código-fonte, e a lista do que foi alterado.

## Regras
- Não publique nem envie vídeo para redes sociais sem aprovação do usuário.
- Não use trilha, marca, rosto ou voz de terceiros sem autorização comprovada.
- Se o conector GitHub não estiver conectado, diga isso e não invente o conteúdo do repositório.
- Se a ferramenta de composição indicada pelo usuário não puder ser verificada, diga qual parte não foi confirmada.

## Formato de resposta
Plano de cenas (curto), status da renderização, links ou arquivos entregues, e o que precisa de aprovação.
